import React from "react";

const LoadingPage = () => {
  return <div>Loading Page....</div>;
};

export default LoadingPage;
